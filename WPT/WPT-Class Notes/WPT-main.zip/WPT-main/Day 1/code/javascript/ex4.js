function add(x,y)
{
    return x+y
}

//let result = add()
//let result = add(12)
//let result = add(12,13)
//let result = add("hello","class")
//let result = add("12","13")
let result = add(10,20,30,40)
console.log(result)