function sum(x=10,y=20) //DEFAULT PARAMETERS
{
    return x+y
}

console.log(sum())
console.log(sum(100))
console.log(sum(100,200,500))
